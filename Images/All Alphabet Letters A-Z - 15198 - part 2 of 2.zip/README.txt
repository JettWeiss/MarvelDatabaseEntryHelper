All Alphabet Letters A-Z by 6brueder on Thingiverse: https://www.thingiverse.com/thing:15198

Summary:
All letters: ABCDEFGHIJKLMNOPQRSTUVWXYZ@ uppercase and these chars: 0123456789?-+Ã¢âÂ¬$&amp;#()ÃÂ£ÃÂ¥. They are based on the the Bitstream Vera Bold Font. Please check the license here http://www-old.gnome.org/fonts/#Final_Bitstream_Vera_FontsThe chars have a height of 40mm and are 10mm deep.created by: www.6brueder.wordpress.com